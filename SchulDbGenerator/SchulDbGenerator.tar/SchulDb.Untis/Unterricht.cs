﻿namespace SchulDb.Untis
{
    public class Unterricht
    {
        public int UntId { get; set; }
        public string Klasse { get; set; }
        public string Lehrer { get; set; }
        public string Fach { get; set; }
        public string Raum { get; set; }
        public int Tag { get; set; }
        public int Stunde { get; set; }
        public string Flag8 { get; set; }
        public string Flag9 { get; set; }
    }
}
