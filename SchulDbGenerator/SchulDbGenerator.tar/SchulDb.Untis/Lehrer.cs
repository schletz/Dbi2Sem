﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchulDb.Untis
{
    public class Lehrer
    {
        public string Nr { get; set; }
        public string Zuname { get; set; }
        public string Vorname { get; set; }
        public string Email { get; set; }
    }
}
