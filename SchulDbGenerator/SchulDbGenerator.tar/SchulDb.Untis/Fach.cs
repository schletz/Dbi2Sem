﻿namespace SchulDb.Untis
{
    public class Fach
    {
        public string Nr { get; set; }
        public string Langname { get; set; }
    }
}
