﻿namespace SchulDb.Untis
{
    public class Raum
    {
        public string Nr { get; set; }
        public string Art { get; set; }
        public string Flag1 { get; set; }
        public string Flag2 { get; set; }
        public string Flag3 { get; set; }
        public string Flag4 { get; set; }
        public string Flag5 { get; set; }
        public int? Kapaz { get; set; }
        public string Flag7 { get; set; }
        public string Flag8 { get; set; }
        public string Flag9 { get; set; }
        public string Flag10 { get; set; }
        public string Flag11 { get; set; }
        public string Flag12 { get; set; }
        public string Flag13 { get; set; }
        public string Flag14 { get; set; }
        public string Flag15 { get; set; }
        public string Flag16 { get; set; }
    }
}
